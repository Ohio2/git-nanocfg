All of the people who have made at least one contribution to nanorc.
Authors are sorted by number of commits.

* Anthony Scopatz
* Elof
* Simon Volpert
* Andrea Dejan Grande
* Alex Taber
* Harsh Shandilya
* Mariusz Smykuła
* Michael Straube
* CoffeeTableEnnui
* Zach DeCook
* Daniel Kaplun
* Philipp
* Tiago Almeida
* yochem
* nl6720
* Thomas Rosenau
* Matthew Cox
* Ritiek Malhotra
* Birger Jarl
* divinity76
* CirKu17
* Geoffrey McClinsey
* Sandro Jäckel
* Philipp Leo Dylong
* Huub de Beer
* Mikael O. Bonnier
* Jeppe Fihl-Pearson
* Ondřej Ešler
* Gareth Jones
* Dan Kaplun
* Aryan Ebrahimpour
* Paduct
* Jody Leonard
* Daniel Jones
* Brandon Gulla
* DesertPunk
* Shmueli Englard
* Ondrej Esler
* jboero
* lopho
* Paul Inder
* Coşku Baş
* Anomitee
* Bryan Ross
* Nicholas Christopoulos
* Sina
* Ross Smith II
* Dante Falzone
* Hunter Peavey
* Dan Pasanen
* Marcus Willock
* Dario Ostuni
* Tim Austin
* Barbz
* Daniel Harbor
* Kyle Stiemann
* Víctor Pont
* Alexey Melezhik
* Martin Wimpress
* Xavier Gouchet
* Marin Marusic
* Elliot Saba
* Jason Ormand
* Ian Mustafa
* Michał Kiełbowicz
* Steven Honeyman
* Filip Szymański
* kaernyk
* Michael Lopez
* amateursuperuser
* Ville Pulkkinen
* Brandon LeBlanc
* matnovak
* Mani Tadayon
* TSUYUSATO Kitsune
* Navid Alipour
* Austin
* Luis Lobo Borobia
* Lephend
* maritaria
* Alessandro Luppi
* floomby
* esler
* Karl
* Eric Wieser
* Evan Troy Owen
* Mickaël Bernardini
* sledgeh
* Per Lundberg
* Brian Recchia
* Ralf Brandenstein
* Tiago Programmer
* PhilipRoman
* pik
* Sander M
* mcnesium
* EarthCitizen
* Jon Langevin
* Eric Ma
* tomcharter365
* Skruppy
* Austin Jackson
* Markus Hoffmann
* Natalie Somersall
* Damian Mee
* Aaron Bishop
* Adrien Pyke
* Cody
* Jan Trejbal
* TUSF
* grandtheftjiujitsu
* John S Long
* Ghost-NULL
* PN Wu (小平)
* CryptoDragonLady
